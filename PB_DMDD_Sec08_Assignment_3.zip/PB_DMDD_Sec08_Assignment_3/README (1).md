===================================================
Converting SQL Database to NoSQL (MongoDB) Database
===================================================

.csv file geneerated in assignment#2 is converted into a MongoDB database.
Additional data of tweets from multiple companies were extracted using twitter API and tweepy library.


Dependencies
============
tweepy, pymongo, pandas, csv libraries
 
Download and install respective libraries using 

#pip install <library_name>


Files
=====
filename: cleaned_investments.csv
This contains the necessary data to analze financial performance of various startups in terms of job prospectus.

filename: MongoDB Atlas investments database (cloud)
This conatains the same information as cleaned_investements.csv in MongoDB format.

To get access to MongoDB Atlas, use
username: PB  password: Assignment3
In case, if you can't access from your IP adress, please send your IP address to banvathshyam.p@northeastern.edu (or) namakkalbalasubramani.p@northeastern.edu

filename: PB_DMDD_Sec08_Assignment_3.ipynb
This contains all the code required, report, tests and their results.
Necessary tests were conducted to ensure that the database conversion to NoSQL database was successful.